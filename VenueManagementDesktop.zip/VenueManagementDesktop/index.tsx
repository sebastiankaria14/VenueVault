import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { MapPin, AlertCircle } from "lucide-react"

export default function LoginUI() {
  return (
    <div className="flex h-screen items-center justify-center bg-gray-100">
      <Card className="w-[350px]">
        <CardHeader className="space-y-1">
          <div className="flex items-center justify-center mb-4">
            <MapPin className="h-12 w-12 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-center">Venue Manager</h2>
          <p className="text-sm text-gray-500 text-center">Enter your email and password to login</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" placeholder="m@example.com" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" />
          </div>
          <Alert variant="destructive" className="hidden">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>Unable to log in. Please check your credentials or contact support.</AlertDescription>
          </Alert>
          <Button className="w-full bg-green-600 hover:bg-green-700 text-white">Log in</Button>
        </CardContent>
        <CardFooter>
          <Button variant="link" className="w-full">Forgot password?</Button>
        </CardFooter>
      </Card>
    </div>
  )
}