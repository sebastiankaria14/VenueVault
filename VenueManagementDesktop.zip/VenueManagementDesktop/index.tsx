import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;

public class LoginPage extends Application {

    private TextField emailField;
    private PasswordField passwordField;
    private Button loginButton;
    private Label errorLabel;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Venue Manager Login");

        VBox layout = new VBox(10);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));

        // Logo
        ImageView logo = new ImageView(new Image("https://example.com/path-to-your-logo.png"));
        logo.setFitHeight(50);
        logo.setFitWidth(50);

        Label titleLabel = new Label("Venue Manager");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Label subtitleLabel = new Label("Enter your email and password to login");
        subtitleLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #666666;");

        emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.setMaxWidth(300);

        passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.setMaxWidth(300);

        loginButton = new Button("Log in");
        loginButton.setMaxWidth(300);
        loginButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");

        errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 14px;");
        errorLabel.setVisible(false);

        Hyperlink forgotPasswordLink = new Hyperlink("Forgot password?");

        layout.getChildren().addAll(logo, titleLabel, subtitleLabel, emailField, passwordField, loginButton, errorLabel, forgotPasswordLink);

        loginButton.setOnAction(e -> handleLogin());

        Scene scene = new Scene(layout, 350, 450);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void handleLogin() {
        String email = emailField.getText();
        String password = passwordField.getText();

        loginButton.setDisable(true);
        loginButton.setText("Logging in...");

        // Simulate API call
        new Thread(() -> {
            try {
                Thread.sleep(1000); // Simulate network delay
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            javafx.application.Platform.runLater(() -> {
                if (email.toLowerCase().contains("admin")) {
                    showError("Unable to log in. Please check your credentials or contact support.");
                } else {
                    // Normally, you would handle successful login here
                    System.out.println("Login successful");
                    errorLabel.setVisible(false);
                }

                loginButton.setDisable(false);
                loginButton.setText("Log in");
            });
        }).start();
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }

    public static void main(String[] args) {
        launch(args);
    }
}