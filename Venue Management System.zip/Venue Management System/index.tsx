import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Home, LayoutDashboard, MapPin, Calendar, HelpCircle, Info, LogOut, Users, DollarSign, TrendingUp } from 'lucide-react'

export default function HomePage() {
  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <aside className="w-64 bg-white shadow-md">
        <ScrollArea className="h-full">
          <div className="p-4">
            <h2 className="text-2xl font-bold mb-4">Venue Manager</h2>
            <nav className="space-y-2">
              <Link href="#" className="flex items-center space-x-2 p-2 bg-gray-200 rounded">
                <Home className="h-5 w-5" />
                <span>Home</span>
              </Link>
              <Link href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded">
                <LayoutDashboard className="h-5 w-5" />
                <span>Dashboard</span>
              </Link>
              <Link href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded">
                <MapPin className="h-5 w-5" />
                <span>Venues</span>
              </Link>
              <Link href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded">
                <Calendar className="h-5 w-5" />
                <span>Bookings</span>
              </Link>
              <Link href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded">
                <HelpCircle className="h-5 w-5" />
                <span>FAQs</span>
              </Link>
              <Link href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded">
                <Info className="h-5 w-5" />
                <span>About Us</span>
              </Link>
            </nav>
          </div>
          <div className="p-4">
            <Button variant="outline" className="w-full flex items-center justify-center space-x-2">
              <LogOut className="h-5 w-5" />
              <span>Logout</span>
            </Button>
          </div>
        </ScrollArea>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 overflow-auto">
        <h1 className="text-3xl font-bold mb-6">Welcome to Venue Manager</h1>
        
        {/* Overview Section */}
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">System Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Venues</CardTitle>
                <MapPin className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">25</div>
                <p className="text-xs text-muted-foreground">+2 from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Bookings</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">132</div>
                <p className="text-xs text-muted-foreground">+15% from last week</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$45,231</div>
                <p className="text-xs text-muted-foreground">+20% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">573</div>
                <p className="text-xs text-muted-foreground">+201 since last year</p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Features Section */}
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">Key Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  Venue Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>Easily add, edit, and manage your venues. Keep track of venue details, capacity, and availability.</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Booking System
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>Streamline your booking process. Manage reservations, handle conflicts, and send automated confirmations.</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Analytics Dashboard
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>Gain insights into your venue performance. Track bookings, revenue, and occupancy rates over time.</p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Call to Action */}
        <section className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Ready to get started?</h2>
          <Button size="lg" className="font-semibold">
            Explore Venues
          </Button>
        </section>
      </main>
    </div>
  )
}