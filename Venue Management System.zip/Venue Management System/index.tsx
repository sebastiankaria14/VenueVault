import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Home, LayoutDashboard, MapPin, Calendar, HelpCircle, Info, LogOut } from 'lucide-react'

export default function VenuePage() {
  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <aside className="w-64 bg-white shadow-md">
        <ScrollArea className="h-full">
          <div className="p-4">
            <h2 className="text-2xl font-bold mb-4">Venue Manager</h2>
            <nav className="space-y-2">
              <Link href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded">
                <Home className="h-5 w-5" />
                <span>Home</span>
              </Link>
              <Link href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded">
                <LayoutDashboard className="h-5 w-5" />
                <span>Dashboard</span>
              </Link>
              <Link href="#" className="flex items-center space-x-2 p-2 bg-gray-200 rounded">
                <MapPin className="h-5 w-5" />
                <span>Venues</span>
              </Link>
              <Link href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded">
                <Calendar className="h-5 w-5" />
                <span>Bookings</span>
              </Link>
              <Link href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded">
                <HelpCircle className="h-5 w-5" />
                <span>FAQs</span>
              </Link>
              <Link href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded">
                <Info className="h-5 w-5" />
                <span>About Us</span>
              </Link>
            </nav>
          </div>
          <div className="p-4">
            <Button variant="outline" className="w-full flex items-center justify-center space-x-2">
              <LogOut className="h-5 w-5" />
              <span>Logout</span>
            </Button>
          </div>
        </ScrollArea>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 overflow-auto">
        <h1 className="text-3xl font-bold mb-6">Venue Details</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((index) => (
            <Card key={index}>
              <CardContent className="p-4">
                <img
                  src={`/placeholder.svg?height=200&width=300`}
                  alt={`Venue ${index}`}
                  className="w-full h-48 object-cover rounded-md mb-4"
                />
                <h2 className="text-xl font-semibold mb-2">Venue {index}</h2>
                <p className="text-gray-600 mb-2">
                  <MapPin className="inline-block mr-1 h-4 w-4" />
                  123 Main St, City, Country
                </p>
                <p className="text-gray-600">
                  <span className="font-semibold">Capacity:</span> 500 people
                </p>
                <p className="mt-2 text-sm text-gray-500">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}